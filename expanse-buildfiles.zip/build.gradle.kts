plugins {
    // Provides `clean` task
    id("base")
}

// no other config needed here; subprojects handle Forge/NeoForge builds
